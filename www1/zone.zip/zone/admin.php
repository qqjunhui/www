<?php
/**
 * Created by PhpStorm.
 * User: 康康
 * Date: 2017/6/30
 * Time: 9:02
 */
header("location:index.php?m=admin&f=login");