<?php
class index extends main {
    function __construct(){
        parent::__construct();
        $this->db=new db('category');
        $this->db1 = new db('lists');
        $this->db3 = new db('minfo');
        $this->db2 = new db('manger');
        $this->smarty->setCompileDir("compile/index");
    }
    function init(){
        $result = $this->db->select();
        $this->smarty->assign("result", $result);
        $this->smarty->assign("login", $this->session->get("login"));
        $member=$this->db3->select();
        $result2=$this->db1->where("status=2 and srec>0")->select();
        $result1=$this->db->select();
        $result3=$this->db2->select();

//        $hitslist=$this->db1->order("hits desc")->limit("0,5")->select();
//        $lovelist=$this->db1->order("good desc")->limit("0,5")->select();
//        $this->smarty->assign("hitslist",$hitslist);
//        $this->smarty->assign("lovelist",$lovelist);
        $this->smarty->assign("list",$result1);
        $this->smarty->assign("content",$result2);
        $this->smarty->assign("member",$member);
        $this->smarty->assign("member1",$result3);
        $this->smarty->assign("mname",$this->session->get("mname"));
        $this->smarty->display("index/index.html");
    }
    function lists(){
        $cid=$_GET['cid'];
        $result = $this->db->select();
        $this->smarty->assign("result", $result);
        $this->smarty->assign("login", $this->session->get("login"));
    }
}