<?php
/**
 * Created by PhpStorm.
 * User: 康康
 * Date: 2017/6/29
 * Time: 10:32
 */
if(!defined("MVC")){
    exit();
}
class lists extends main{
    function __construct(){
        parent::__construct();
        $this->smarty->setCompileDir("compile/admin");
    }
    function show(){
        $db1=new db('lists');
        if(isset($_GET["status"])){
            $num=$db1->where($_GET['status'])->select("select count(lid) as lid from lists ");
        }else{
            $num=$db1->select("select count(lid) as lid from lists ");
        }
        $page=new page();
        $page->pageNum=5;
        $page->total=count($num);
        $str=$page->show();
        $limit=$page->limit;
        $this->smarty->assign("pages",$str);
        $array=$db1->where("status=2")->order("ltime desc ".$limit)->select();
        $this->smarty->assign("arr",$array);
        $this->smarty->display("admin/show.html");
    }
}