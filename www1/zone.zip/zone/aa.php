<?php
/**
 * Created by PhpStorm.
 * User: 康康
 * Date: 2017/6/27
 * Time: 23:47
 */
include_once "img.php";
$obj=new code();
$obj->output();