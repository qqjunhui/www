<?php
if(!defined("MVC")){
    exit();
}
return array(
    "database"=>array(
        "host"=>"localhost",
        "user"=>"root",
        "pass"=>"",
        "database"=>"zone",
        "port"=>"3306",
    )
);
