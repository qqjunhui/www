// window.onload=function(){
// 	let plp=document.querySelectorAll('.ljb-qqq p')
// 	let blb=document.querySelectorAll('.olm')
// 	for(let i=0;i<plp.length;i++){
// 		plp[i].onmouseover=function(){
// 			for(let j=0;j<blb.length;j++){
// 				blb[j].style.display="none";
// 			}
// 			blb[i].style.display="block";
// 		}
// 	}








// }