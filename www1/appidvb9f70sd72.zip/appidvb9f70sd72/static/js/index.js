/**
 * Created by think on 2017/5/10.
 */
$(function () {
    let flag=1;
    $('#main-menu > li > a').click(function(){
            $(this).next('ul').slideToggle(200);

    })


})
