<?php
$db=new mysqli("sqld.duapp.com","5f0a27b668e646fb8041492e31187215","ef267724bce545818756ef18cc4c8e5b","ofVsdsWJQQGxIeGDfGlL","4050");

$db->query("set names utf8");

