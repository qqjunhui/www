<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<p>系统信息</p>
<p>新闻管理系统1.0</p>
<p>操作环境 php+mysql+apache</p>
<p>时间：2017-6-11</p>
<dt>
    <dl>作者信息</dl>
    <dd>六月十五</dd>
    <dd>前端设计</dd>
    <dd>后台设计</dd>
    <dd>UI设计</dd>
</dt>
</body>
</html>