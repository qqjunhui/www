<?php
/**
 * Created by PhpStorm.
 * User: think
 * Date: 2017/5/10
 * Time: 18:18
 */
session_start();
if(!isset($_SESSION['user'])){
    $mess="请登录！";
    $src="login.html";
    include "login/index.html";
    exit;
}
header("content-type:text/html;charset=utf8");
$db=new mysqli("sqld.duapp.com","5f0a27b668e646fb8041492e31187215","ef267724bce545818756ef18cc4c8e5b","ofVsdsWJQQGxIeGDfGlL","4050");
$db->query("set names utf8");
?>