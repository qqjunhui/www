<?php
include  "../libs/upload.php";

$obj=new upload();
//$obj->root="../root";
$obj->move();
?>