<?php


include_once "../admin/public1.php";
include "../libs/public.php";
    checkname($db);
?>