<?php
/**
 * Created by PhpStorm.
 * User: think
 * Date: 2017/6/16
 * Time: 17:58
 */

include_once "../admin/public1.php";
include "../libs/public.php";
loginname($db);