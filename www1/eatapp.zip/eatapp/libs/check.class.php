<?php
/**
 * Created by PhpStorm.
 * User: hanxiao
 * Date: 2017/6/27
 * Time: 下午7:28
 */
class check{
    function check(){
//        include_once LIBS_PATH."checkimg.php";
//        $obj=new code();
//        $obj->font=array("one"=>"../static/four.ttf");
//        $session=new session();
//        $session->set("check",$obj->codeUrl);
//        $obj->output();
    }
}