<?php
$str="asdasdasd";
echo $str[mt_rand(0,strlen($str)-1)];