<?php
/**
 * Created by PhpStorm.
 * User: hanxiao
 * Date: 2017/6/22
 * Time: 下午7:29
 */
include_once TEM_PATH."qyh-index.html";