<?php
return array(
    "database"=>array(
        "host"=>"localhost",
        "user"=>"root",
        "pass"=>"",
        "database"=>"eatapp",
        "port"=>"3306",
    )
)

?>