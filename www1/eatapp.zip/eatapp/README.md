# eatapp
- mvc框架  用zepto.js
- 做前台页面时联系后台数据逻辑
- 图标及icon分类放置在static／img文件夹下